# Συμβολή

1. Ανοίξτε ένα issue και περιγράψτε την πρόταση.
2. Κάντε fork το repo και δημιουργήστε branch (`git checkout -b feature/my-feature`).
3. Κάντε commit με καθαρά μηνύματα.
4. Ανοίξτε Pull Request και συνδέστε το με το issue.
