# Contributing

1. Open an issue to describe your proposal.
2. Fork the repo and create a branch (`git checkout -b feature/my-feature`).
3. Commit with clear messages.
4. Open a Pull Request and link it to the issue.
