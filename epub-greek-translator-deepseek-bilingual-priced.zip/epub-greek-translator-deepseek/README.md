# EPUB → Greek Translator (DeepSeek)

**Languages:** [English](README.en.md) · [Ελληνικά](README.el.md)

Small Python GUI tool that translates `.epub` books to **Greek** using the DeepSeek API.
